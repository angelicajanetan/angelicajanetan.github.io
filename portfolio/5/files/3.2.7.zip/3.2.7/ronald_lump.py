"""
Garrett Gibo and AJ Tan
3.2.7 Investigating with Data
Data Project
AP Computer Science Principles
Period 6
"""

import os
import matplotlib.pyplot as plt
import numpy as np


def plot_data(filename):
    x_axis_data = []
    
    # creates differnet variable depending on file
    if filename == 'Terrorism in US.csv':
        y_axis_data = []
    else: 
        y_axis_data = [[] for i in range(7)]
        
    # gets full file name and opens file.
    directory = os.path.dirname(os.path.abspath(__file__))
    datafile = open(os.path.join(directory, filename),'r')

    # iterates through every line in file
    for line_number, line in enumerate(datafile):
        if filename == 'Terrorism in US.csv' and line_number > 0:
                year, number = line.split(',')  # unpacks data from comma-deliniated file
                x_axis_data.append(int(year))  # append data to list to use for plot
                y_axis_data.append(int(number[:-1]))
        else:
            if line_number > 1:
                year, Iran, Iraq, Libya, Somalia, Sudan, Syria, Yemen = line.split(',')
                x_axis_data.append(int(year))
                contries = [Iran, Iraq, Libya, Somalia, Sudan, Syria, Yemen[:-1]]
                for i in range(7):
                    y_axis_data[i].append(int(contries[i]))
                    
    else: datafile.close()  # closes datafile after iterating through every line
    return x_axis_data, y_axis_data  # returns x- and y- coordinate data points

# MAIN
years, attacks = plot_data('Terrorism in US.csv')   
years1, immigration = plot_data('immigration trends.csv')
countries = [['Iran','bo'],['Iraq','go'],['Libya','ro'],['Somalia','co'], ['Sudan','mo'], ['Syria','yo'], ['Yemen','ko']]
lines, names = [], []  # empty lists to be used to make legend

# Plot on one set of axes.
fig, ax = plt.subplots(1,2,figsize=(20, 10))
fit = np.polyfit(years, attacks, 3)  # calculates coefficients for regression function
fit_fn = np.poly1d(fit)  # creates function for regression line
ax[0].plot(years, attacks, 'ro', years, fit_fn(years), '--k')  # plots points onto graph with regression line

for k, country in enumerate(immigration):
    fit = np.polyfit(years1, country, 2)  
    fit_fn = np.poly1d(fit)
    ax[1].plot(years1, country, countries[k][1], years1, fit_fn(years1), '--k')
    lines += ax[1].plot(years1, country, countries[k][1])  # adds data from line to list to be used for legend
    names.append(countries[k][0])


'''
Modifactions to the design aesthetic i.e. font size, font color, background
color, and axes colors
'''
ax[0].set_title('Terrorism in the U.S.', color='white', fontsize=25)
ax[0].set_xlabel('Years', color='white', fontsize=25)
ax[0].set_ylabel('Number of Attacks', color='white', fontsize=25)
ax[0].tick_params(axis='x', colors='white')
ax[0].tick_params(axis='y', colors='white')
ax[0].set_axis_bgcolor('white')

ax[1].set_title('Immigration Trends', color='white', fontsize=25)
ax[1].set_xlabel('Years', color='white', fontsize=25)
ax[1].set_ylabel('Number of Immigrants', color='white', fontsize=25)
ax[1].tick_params(axis='x', colors='white')
ax[1].tick_params(axis='y', colors='white')
ax[1].set_ylim(0,400000)
ax[1].set_axis_bgcolor('white')

legend = ax[1].legend(tuple(lines), tuple(names), title='Countries', loc='best')  # creates legend
legend.get_frame().set_facecolor('white')

fig.set_facecolor('black')
fig.show()  # displays visualization

